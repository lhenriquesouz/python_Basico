print('Numeros de 350 a 1000')

for item in range(350, 1001):
    print('//',item)
