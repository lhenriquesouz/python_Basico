print('Imrpimindo numeros pares')

for item in range(1, 201):
    if item%2 == 0:
        print('//', item)
