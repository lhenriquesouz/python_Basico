print('Imprimo numeros impares de 500 a 1000 em ordem decrescente ')

for item in range(500, 1000):
    if item%2 == 1: 
      print(item)
        
